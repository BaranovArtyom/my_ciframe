<?php
ini_set('display_errors', 1);
error_reporting(E_ALL & ~E_NOTICE);
use Ciframe\Moysklad;
use Ciframe\MSParameters;
use Ciframe\Zvonobot;
require_once "ms_inc.php";

$moyskladLogin = "api@manager245";
$moyskladPassword = "api1111";
$apiKey = "eQwj7i7OkMCkfaCeCZ9fn6EvYw5kU3xgg6VMIwwJOrxo6b0J7DFxaSJrgW4I";
$outgoingPhone = "79315068121";
$managerPhone = "79315068121";
$callId = 312953;
$confirmStates = array(
    "3b4a36de-b1cd-11e9-912f-f3d4001e97fc"=>"Подтвержден Екатерина",
    "06bfbfde-b696-11e9-912f-f3d400060ba5"=>"Подтвержден Анна",
    "06bfc5d1-b696-11e9-912f-f3d400060ba6"=>"Подтвержден Яндекс",
    "aac65d4a-b8d3-11e9-9ff4-34e800011efc"=>"Подтвержден ВТБ",
    "f07d97a3-c250-11e9-9107-50480014df81"=>"Подтвержден Тинькофф",
);
$finishedStatus = "ea9e8a58-383e-11ea-0a80-01af000416cd";
$canceledStatus = "ea9e8fc1-383e-11ea-0a80-01af000416ce";

$ms = new Moysklad($moyskladLogin, $moyskladPassword);
$db = new mysqli("localhost","034725012_api", "1rtd1111", "ghost_api");
$zb = new Zvonobot($apiKey);

$logFile = fopen("cron_log.log", "a+");
fwrite($logFile, "scriptStart: " . date("d-m-Y H:i:s", time()) . " - intType=" . $_GET["intType"]."\n");

if($_GET["intType"]=="zvonobotCallback"){
    $response = file_get_contents('php://input');
    $apiCalls = json_decode($response,JSON_UNESCAPED_UNICODE);
    foreach ($apiCalls["apiCalls"] as $apiCall){
        $callId = $apiCall["id"];
        $callStatus = $apiCall["calls"][0]["status"];
        $msIdStatus = "";
        switch ($callStatus){
            case "canceled":
                $msIdStatus = $canceledStatus;
                break;
            case "finished":
                $msIdStatus = $finishedStatus;
                break;
            default:
                break;
        }

        if($msIdStatus!=""){
            $msOrder = $db->query("SELECT * FROM ms_order_call WHERE zb_call_id='$callId'")->fetch_assoc();
            if($msOrder==null){
                continue;
            }
            $msData = array(
                "state"=>array(
                    "meta"=>array(
                        "href"=> "https://online.moysklad.ru/api/remap/1.2/entity/customerorder/metadata/states/".$msIdStatus,
                        "type"=> "state",
                        "mediaType"=> "application/json"
                    )
                )
            );
            $ms->put("entity/customerorder/".$msOrder["ms_order_id"], $msData);
            $db->query("UPDATE ms_order_call SET ms_call_status=1, zb_call_status='$callStatus' WHERE zb_call_id='$callId'");
        }
    }

    header( 'HTTP/1.0 200 OK');
}

if($_GET["intType"]=="msCallback"){
    $response = file_get_contents('php://input');
    $msEvents = json_decode($response,  JSON_UNESCAPED_UNICODE);
    foreach ($msEvents["events"] as $event){
        $msOrder = $ms->getByLink($event["meta"]["href"]."?expand=state,agent");
        if(isset($confirmStates[$msOrder["state"]["id"]])) {
            $check = $db->query("SELECT * FROM ms_order_call WHERE ms_order_id='".$msOrder["id"]."' AND ms_order_state_id='".$msOrder["state"]["id"]."'")->fetch_assoc();
            $dontCall = false;
            foreach ($msOrder["attributes"] as $attribute){
                if($attribute["id"]=="7595541f-4337-11ea-0a80-047e000302ff" && $attribute["value"]){
                    $dontCall = true;
                }
            }
            if($check!=null || $dontCall){
                continue;
            }
            $phone = str_replace(array("(", ")", "+", " ", "-"), "", $msOrder["agent"]["phone"]);
            $zData = array(
                "phone" => $phone,
                "outgoingPhone" => $outgoingPhone,
                "record" => array(
                    "id" => $callId
                ),
                "webhookUrl" => "http://1rtd.ru/zb/index.php?intType=zvonobotCallback",
                "recognize" => 1,
                "ivrs" => array(
                    array(
                        "keyWords"=> "да",
                        "managerPhone" => $managerPhone,
                        "id" => 1,
                        "recognize" => 0,
                        "ivrs" => array()
                    ),
                )
            );

            $createCall = $zb->create($zData);
            fwrite($logFile, $createCall);
            if (isset($createCall["data"][0]["id"])) {
                $db->query("INSERT INTO ms_order_call SET ms_order_id='" . $msOrder["id"] . "', ms_order_state_id='" . $msOrder["state"]["id"] . "', zb_call_id='" . $createCall["data"][0]["id"] . "', ms_call_status='0'");
            }
        }
    }
    header( 'HTTP/1.0 200 OK');
}

if($_GET["intType"]=="createHook"){
    $msData = array(
        "url"=> "http://1rtd.ru/zb/index.php?intType=msCallback",
        "action"=> "UPDATE",
        "entityType"=> "customerorder"
    );
    $check = $ms->post("entity/webhook",$msData);
}

$db->close();
fwrite($logFile, "scriptEnd: " . date("d-m-Y H:i:s", time()) . " - intType=" . $_GET["intType"]."\n");
fclose($logFile);

/*if($_GET["intType"]=="checkOrders"){
    $params = new MSParameters();
    $params->addFilter("updated",date("Y-m-d H:i:s",time()-60*10),">");
    $msOrders = $ms->get("entity/customerorder",1000, 0, $params->getFilter(),"state,agent");

    foreach ($msOrders["rows"] as $msOrder){
        if(isset($confirmStates[$msOrder["state"]["id"]])){
            $check = $db->query("SELECT * FROM ms_order_states WHERE order_id='".$msOrder["id"]."' AND state_id='".$msOrder["state"]["id"]."'")->fetch_assoc();
            if($check==null){
                $phone = str_replace(array("(",")","+"," ","-"),"",$msOrder["agent"]["phone"]);
                $zData = array(
                    "phone"=>$phone,
                    "outgoingPhone"=>$outgoingPhone,
                    "record"=>array(
                        "id"=>$callId
                    ),
                    "webhookUrl"=> "http://1rtd.ru/zb/index.php?intType=zvonobotCallback",
                    "recognize"=>1,
                    "irvs"=>array(
                        "anyWord"=> 1,
                        "managerPhone"=> "+7(909)594-59-92",
                        "id"=> 1,
                        "recognize"=>0,
                        "ivrs"=>array()
                    )
                );

                $createCall = $zb->create($zData);
                if(isset($createCall["id"])){
                    $db->query("INSERT INTO ms_order_call SET ms_order_id='".$msOrder["id"]."', ms_order_state_id='".$msOrder["state"]["id"]."', zb_call_id='".$createCall["id"]."'");
                }
            }
        }
    }

    $apiCallIdList = array();
    $ordersCalls = $db->query("SELECT * FROM ms_order_call WHERE ms_call_status='0'");
    while ($orderCall = $ordersCalls->fetch_assoc()){
        $apiCallIdList[] = $orderCall["zb_call_id"];
    }

    $zData = array(
        "apiCallIdList"=>$apiCallIdList
    );

    $zbCalls = $zb->get($zData);
    foreach ($zbCalls["data"] as $zbCall){
        $callId = $zbCall["id"];
        $callStatus = $zbCall["calls"][0]["status"];
        $msIdStatus = "";
        switch ($callStatus){
            case "canceled":
                $msIdStatus = $canceledStatus;
                break;
            case "finished":
                $msIdStatus = $finishedStatus;
                break;
            default:
                break;
        }

        if($msIdStatus!=""){
            $msOrder = $db->query("SELECT * FROM ms_order_call WHERE zb_call_id='$callId'");
            $msData = array(
                "state"=>array(
                    "meta"=>array(
                        "href"=> "https://online.moysklad.ru/api/remap/1.2/entity/customerorder/metadata/states/".$msIdStatus,
                        "type"=> "state",
                        "mediaType"=> "application/json"
                    )
                )
            );

            $ms->put("entity/customerorder/".$msOrder["ms_order_id"], $msData);
            $db->query("UPDATE ms_call_status SET ");
        }
    }
}*/